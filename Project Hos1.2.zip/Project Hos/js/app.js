/**
 * SPK Smart Wayfinding - Application Controller
 * จัดการ UI, การเลือกจุดหมาย, ขั้นตอนการนำทาง, เสียงสังเคราะห์, แผนที่ และระบบล็อกอินผ่านมือถือ
 */

class HospitalApp {
  constructor() {
    this.data = window.HOSPITAL_DATA;
    this.router = new window.HospitalRouter(this.data);

    // State เริ่มต้น
    this.startNodeId = "entrance_1"; // ค่าเริ่มต้น: ประตูทางเข้าหลัก
    this.destinationNodeId = null;
    this.currentRoute = null;
    this.currentStepIndex = 0;
    this.activeView = "photo"; // 'photo' หรือ 'map'
    this.currentMapFloor = "floor1";
    this.isVoiceEnabled = true;
    this.fontSizeLevel = "normal"; // normal, large, xlarge

    // สถานะผู้ใช้งาน (Auth State)
    this.currentUser = JSON.parse(localStorage.getItem('spk_user') || 'null');

    // Speech & Voice System
    this.speechSynthesis = window.speechSynthesis || null;
    this.thaiVoice = null;
    this.currentAudio = null; // สำหรับ Fallback HTML5 Audio
    this.audioUnlocked = false;

    this.initVoiceSystem();
    this.init();
  }

  // เตรียมระบบเสียงภาษาไทย (ค้นหา Voice และดักจับ voiceschanged)
  initVoiceSystem() {
    if (!this.speechSynthesis) return;

    const findThaiVoice = () => {
      const voices = this.speechSynthesis.getVoices();
      // ค้นหาเสียงที่รองรับภาษาไทย
      this.thaiVoice = voices.find(v => 
        (v.lang && (v.lang.toLowerCase() === 'th-th' || v.lang.toLowerCase().startsWith('th'))) ||
        (v.name && v.name.toLowerCase().includes('thai'))
      );
      if (this.thaiVoice) {
        console.log('พบเสียงภาษาไทยในเครื่อง:', this.thaiVoice.name);
      }
    };

    findThaiVoice();
    if (this.speechSynthesis.onvoiceschanged !== undefined) {
      this.speechSynthesis.onvoiceschanged = findThaiVoice;
    }

    // ปลดล็อก Audio Policy เมื่อผู้ใช้คลิกหรือแตะหน้าจอครั้งแรก
    const unlockAudio = () => {
      if (!this.audioUnlocked) {
        this.audioUnlocked = true;
        // ปลุก Web Speech API และสร้าง Silent utterance สั้นๆ
        if (this.speechSynthesis) {
          const silent = new SpeechSynthesisUtterance('');
          this.speechSynthesis.speak(silent);
        }
        window.removeEventListener('click', unlockAudio);
        window.removeEventListener('touchstart', unlockAudio);
      }
    };
    window.addEventListener('click', unlockAudio, { once: true });
    window.addEventListener('touchstart', unlockAudio, { once: true });
  }

  init() {
    this.parseUrlParameters();
    this.renderStartPoints();
    this.renderQuickCategories();
    this.renderDestinationOptions();
    this.setupEventListeners();
    this.setupAuthListeners();
    this.applyFontSize(this.fontSizeLevel);
    this.updateUserSessionUI();

    // หากเปิดมาพร้อมกับมี destination ใน URL ให้เริ่มนำทางทันที
    if (this.destinationNodeId) {
      this.startNavigation(this.destinationNodeId);
    } else {
      this.updateStartPointDisplay();
    }
  }

  // อ่าน Query Parameter จาก URL (เช่น ?start=screening&dest=lab_blood)
  parseUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    const startParam = urlParams.get('start');
    const destParam = urlParams.get('dest');

    if (startParam && this.data.nodes[startParam]) {
      this.startNodeId = startParam;
      this.showToast(`📌 กำหนดจุดเริ่มต้น: ${this.data.nodes[startParam].name}`);
    }

    if (destParam && this.data.nodes[destParam]) {
      this.destinationNodeId = destParam;
    }
  }

  // ==========================================
  // ระบบเข้าสู่ระบบผ่านมือถือ (Authentication)
  // ==========================================
  setupAuthListeners() {
    const btnHeaderLogin = document.getElementById('btn-header-login');
    const loginModal = document.getElementById('login-modal');
    const btnCloseLogin = document.getElementById('btn-close-login-modal');
    const tabPatient = document.getElementById('tab-login-patient');
    const tabStaff = document.getElementById('tab-login-staff');
    const formPatient = document.getElementById('form-patient-login');
    const formStaff = document.getElementById('form-staff-login');
    const btnSubmitPatient = document.getElementById('btn-submit-patient-login');
    const btnSubmitStaff = document.getElementById('btn-submit-staff-login');
    const btnGuest = document.getElementById('btn-login-guest');
    const btnPatientLogout = document.getElementById('btn-patient-logout');
    const btnStaffLogout = document.getElementById('btn-staff-logout');
    const btnStartPatientRoute = document.getElementById('btn-start-patient-route');

    // เปิด Modal ล็อกอิน
    if (btnHeaderLogin) {
      btnHeaderLogin.addEventListener('click', () => {
        if (this.currentUser) {
          // หากล็อกอินอยู่แล้ว กดเพื่อดูสถานะหรือยืนยันออกจากระบบ
          if (confirm(`คุณเข้าสู่ระบบอยู่แล้วในชื่อ: ${this.currentUser.name}\nต้องการออกจากระบบหรือไม่?`)) {
            this.logout();
          }
        } else {
          loginModal.classList.remove('hidden');
        }
      });
    }

    if (btnCloseLogin) {
      btnCloseLogin.addEventListener('click', () => loginModal.classList.add('hidden'));
    }

    // สลับแท็บ ผู้ป่วย VS เจ้าหน้าที่
    if (tabPatient && tabStaff) {
      tabPatient.addEventListener('click', () => {
        tabPatient.className = "flex-1 py-2 rounded-lg bg-sky-600 text-white shadow-sm transition-all";
        tabStaff.className = "flex-1 py-2 rounded-lg text-slate-600 hover:bg-slate-200 transition-all";
        formPatient.classList.remove('hidden');
        formStaff.classList.add('hidden');
      });

      tabStaff.addEventListener('click', () => {
        tabStaff.className = "flex-1 py-2 rounded-lg bg-slate-800 text-white shadow-sm transition-all";
        tabPatient.className = "flex-1 py-2 rounded-lg text-slate-600 hover:bg-slate-200 transition-all";
        formStaff.classList.remove('hidden');
        formPatient.classList.add('hidden');
      });
    }

    // ล็อกอินผู้ป่วยด้วย HN / บัตรประชาชน / เบอร์โทร
    if (btnSubmitPatient) {
      btnSubmitPatient.addEventListener('click', () => {
        const inputVal = document.getElementById('patient-login-input').value.trim();
        if (!inputVal) {
          alert('กรุณากรอกเลขประจำตัวผู้ป่วย (HN) หรือเบอร์โทรศัพท์');
          return;
        }

        const foundPatient = this.data.mockPatients.find(p => 
          p.hn === inputVal || 
          p.citizenId === inputVal || 
          p.phone === inputVal
        );

        if (foundPatient) {
          this.loginAsPatient(foundPatient);
          loginModal.classList.add('hidden');
        } else {
          alert('ไม่พบข้อมูลการนัดหมายตามที่ระบุ กรุณาทดลองเลือกคนไข้ตัวอย่างด้านล่าง');
        }
      });
    }

    // ปุ่มเลือกคนไข้ตัวอย่าง 1-Click Demo
    document.querySelectorAll('.quick-patient-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const hn = btn.dataset.hn;
        const patient = this.data.mockPatients.find(p => p.hn === hn);
        if (patient) {
          this.loginAsPatient(patient);
          loginModal.classList.add('hidden');
        }
      });
    });

    // ปุ่มเข้าใช้งานแบบ Guest
    if (btnGuest) {
      btnGuest.addEventListener('click', () => {
        loginModal.classList.add('hidden');
        this.showToast('เข้าใช้งานในโหมดบุคคลทั่วไป');
      });
    }

    // ล็อกอินเจ้าหน้าที่ IT
    if (btnSubmitStaff) {
      btnSubmitStaff.addEventListener('click', () => {
        const u = document.getElementById('staff-username-input').value.trim();
        const p = document.getElementById('staff-password-input').value.trim();

        const foundStaff = this.data.staffAccounts.find(s => s.username === u && s.password === p);
        if (foundStaff) {
          this.loginAsStaff(foundStaff);
          loginModal.classList.add('hidden');
        } else {
          alert('ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง (รหัสทดสอบ: admin / 1234)');
        }
      });
    }

    // ปุ่มออกจากระบบ
    if (btnPatientLogout) btnPatientLogout.addEventListener('click', () => this.logout());
    if (btnStaffLogout) btnStaffLogout.addEventListener('click', () => this.logout());

    // ปุ่มนำทางไปยังจุดตรวจตามใบนัดทันที
    if (btnStartPatientRoute) {
      btnStartPatientRoute.addEventListener('click', () => {
        if (this.currentUser && this.currentUser.appointment) {
          const target = this.currentUser.appointment.targetNode;
          this.startNavigation(target);
        }
      });
    }
  }

  loginAsPatient(patient) {
    this.currentUser = {
      type: 'patient',
      ...patient
    };
    localStorage.setItem('spk_user', JSON.stringify(this.currentUser));
    this.updateUserSessionUI();
    this.showToast(`ยินดีต้อนรับ ${patient.name}`);
  }

  loginAsStaff(staff) {
    this.currentUser = {
      type: 'staff',
      ...staff
    };
    localStorage.setItem('spk_user', JSON.stringify(this.currentUser));
    this.updateUserSessionUI();
    this.showToast(`เข้าสู่ระบบในฐานะ: ${staff.name}`);
  }

  logout() {
    this.currentUser = null;
    localStorage.removeItem('spk_user');
    this.updateUserSessionUI();
    this.showToast('ออกจากระบบเรียบร้อยแล้ว');
  }

  // อัปเดตส่วนแสดงผลเมื่อสถานะผู้ใช้เปลี่ยน
  updateUserSessionUI() {
    const badgeName = document.getElementById('user-badge-name');
    const badgeIcon = document.getElementById('user-badge-icon');
    const patientCard = document.getElementById('patient-appointment-card');
    const staffCard = document.getElementById('staff-admin-card');

    if (!this.currentUser) {
      if (badgeName) badgeName.textContent = "เข้าสู่ระบบ";
      if (badgeIcon) badgeIcon.textContent = "👤";
      if (patientCard) patientCard.classList.add('hidden');
      if (staffCard) staffCard.classList.add('hidden');
      return;
    }

    if (this.currentUser.type === 'patient') {
      if (badgeName) badgeName.textContent = this.currentUser.name.split(' ')[0];
      if (badgeIcon) badgeIcon.textContent = "🩺";
      if (staffCard) staffCard.classList.add('hidden');

      // แสดงข้อมูลการ์ดใบนัด
      if (patientCard) {
        patientCard.classList.remove('hidden');
        document.getElementById('patient-name-display').textContent = this.currentUser.name;
        document.getElementById('patient-hn-display').textContent = `HN: ${this.currentUser.hn} | อายุ ${this.currentUser.age} ปี`;
        document.getElementById('patient-rights-badge').textContent = this.currentUser.rights;
        document.getElementById('patient-time-display').textContent = this.currentUser.appointment.time;
        document.getElementById('patient-dept-display').textContent = this.currentUser.appointment.department;
        document.getElementById('patient-notice-box').textContent = this.currentUser.appointment.currentStepNotice;
      }
    } else if (this.currentUser.type === 'staff') {
      if (badgeName) badgeName.textContent = "ฝ่าย IT";
      if (badgeIcon) badgeIcon.textContent = "🛡️";
      if (patientCard) patientCard.classList.add('hidden');
      if (staffCard) {
        staffCard.classList.remove('hidden');
        document.getElementById('staff-name-display').textContent = this.currentUser.name;
      }
    }
  }

  // ==========================================
  // การจัดการจุดเริ่มต้น และการนำทาง
  // ==========================================

  // แสดงตัวเลือกจุดเริ่มต้น (Modal หรือ Dropdown)
  renderStartPoints() {
    const selectElem = document.getElementById('start-location-select');
    if (!selectElem) return;

    selectElem.innerHTML = '';
    const startNodes = Object.values(this.data.nodes).filter(n => n.isStartPoint || n.floorNumber === 1);

    startNodes.forEach(node => {
      const opt = document.createElement('option');
      opt.value = node.id;
      opt.textContent = `[${node.floor === 'floor1' ? 'ชั้น 1' : 'ชั้น 2'}] ${node.name}`;
      if (node.id === this.startNodeId) opt.selected = true;
      selectElem.appendChild(opt);
    });
  }

  // แสดงการ์ดปุ่มลัดปลายทางด่วนสำหรับผู้สูงอายุ
  renderQuickCategories() {
    const container = document.getElementById('quick-categories-container');
    if (!container) return;

    container.innerHTML = '';
    this.data.quickCategories.forEach(cat => {
      const btn = document.createElement('button');
      btn.className = `quick-btn flex items-center p-3.5 bg-white border-2 border-slate-200 hover:border-sky-500 rounded-2xl shadow-sm text-left transition-all w-full group`;
      btn.innerHTML = `
        <div class="w-12 h-12 rounded-xl flex items-center justify-center text-2xl mr-3.5 ${cat.color} text-white flex-shrink-0 shadow-sm">
          ${cat.icon}
        </div>
        <div class="flex-1 min-w-0">
          <div class="font-bold text-slate-800 text-lg group-hover:text-sky-600 truncate">${cat.title}</div>
          <div class="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
            <span class="inline-block w-2 h-2 rounded-full bg-slate-400"></span>
            ${cat.floor}
          </div>
        </div>
        <div class="text-slate-400 group-hover:text-sky-500 pl-2">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 5l7 7-7 7"/></svg>
        </div>
      `;
      btn.addEventListener('click', () => {
        this.startNavigation(cat.targetNode);
      });
      container.appendChild(btn);
    });
  }

  // แสดงรายการห้องทั้งหมดสำหรับ Dropdown ค้นหา
  renderDestinationOptions() {
    const datalist = document.getElementById('destinations-list');
    if (!datalist) return;

    datalist.innerHTML = '';
    Object.values(this.data.nodes).forEach(node => {
      if (node.id !== this.startNodeId) {
        const option = document.createElement('option');
        option.value = node.name;
        option.dataset.id = node.id;
        datalist.appendChild(option);
      }
    });
  }

  // ผูก Event Listeners ทั่วไป
  setupEventListeners() {
    // เลือกจุดเริ่มต้นจาก Select
    const startSelect = document.getElementById('start-location-select');
    if (startSelect) {
      startSelect.addEventListener('change', (e) => {
        this.startNodeId = e.target.value;
        this.updateStartPointDisplay();
        if (this.destinationNodeId) {
          this.startNavigation(this.destinationNodeId);
        }
      });
    }

    // ช่องค้นหาปลายทาง
    const searchInput = document.getElementById('search-destination-input');
    const searchBtn = document.getElementById('search-destination-btn');

    const handleSearch = () => {
      const query = searchInput.value.trim().toLowerCase();
      if (!query) return;

      const matchedNode = Object.values(this.data.nodes).find(node => 
        node.name.toLowerCase().includes(query) ||
        node.shortName.toLowerCase().includes(query) ||
        node.description.toLowerCase().includes(query)
      );

      if (matchedNode) {
        this.startNavigation(matchedNode.id);
        searchInput.value = '';
      } else {
        alert(`ไม่พบสถานที่: "${query}" กรุณาลองค้นหาคำว่า เจาะเลือด, ยา, เอกซเรย์ หรืออายุรกรรม`);
      }
    };

    if (searchBtn) searchBtn.addEventListener('click', handleSearch);
    if (searchInput) {
      searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSearch();
      });
    }

    // ปุ่มสลับโหมดนำทาง (รูปภาพ <-> แผนที่)
    const btnViewPhoto = document.getElementById('btn-view-photo');
    const btnViewMap = document.getElementById('btn-view-map');

    if (btnViewPhoto) btnViewPhoto.addEventListener('click', () => this.switchView('photo'));
    if (btnViewMap) btnViewMap.addEventListener('click', () => this.switchView('map'));

    // ปุ่มการนำทางทีละก้าว (Next / Prev)
    const btnNextStep = document.getElementById('btn-next-step');
    const btnPrevStep = document.getElementById('btn-prev-step');
    const btnSpeakAgain = document.getElementById('btn-speak-again');
    const btnCancelNav = document.getElementById('btn-cancel-nav');

    if (btnNextStep) btnNextStep.addEventListener('click', () => this.nextStep());
    if (btnPrevStep) btnPrevStep.addEventListener('click', () => this.prevStep());
    if (btnSpeakAgain) btnSpeakAgain.addEventListener('click', () => this.speakCurrentStep());
    if (btnCancelNav) btnCancelNav.addEventListener('click', () => this.cancelNavigation());

    // ปุ่มปรับขนาดฟอนต์ (สำหรับผู้สูงอายุ)
    const btnFontNormal = document.getElementById('btn-font-normal');
    const btnFontLarge = document.getElementById('btn-font-large');
    const btnFontXLarge = document.getElementById('btn-font-xlarge');

    if (btnFontNormal) btnFontNormal.addEventListener('click', () => this.applyFontSize('normal'));
    if (btnFontLarge) btnFontLarge.addEventListener('click', () => this.applyFontSize('large'));
    if (btnFontXLarge) btnFontXLarge.addEventListener('click', () => this.applyFontSize('xlarge'));

    // สลับชั้นบนแผนที่
    const btnFloor1 = document.getElementById('map-btn-floor1');
    const btnFloor2 = document.getElementById('map-btn-floor2');

    if (btnFloor1) btnFloor1.addEventListener('click', () => this.changeMapFloor('floor1'));
    if (btnFloor2) btnFloor2.addEventListener('click', () => this.changeMapFloor('floor2'));

    // ปุ่มจำลองสแกน QR Code เพื่อเปลี่ยนจุด
    const btnSimulateQr = document.getElementById('btn-simulate-qr');
    if (btnSimulateQr) btnSimulateQr.addEventListener('click', () => this.openQrSelectorModal());
  }

  // อัปเดตข้อความแสดงจุดเริ่มต้นปัจจุบัน
  updateStartPointDisplay() {
    const startNode = this.data.nodes[this.startNodeId];
    const displayElem = document.getElementById('current-start-name');
    if (displayElem && startNode) {
      displayElem.textContent = startNode.shortName || startNode.name;
    }
  }

  // เริ่มต้นการนำทางไปยังปลายทาง
  startNavigation(destinationId) {
    if (!this.data.nodes[destinationId]) {
      alert("ไม่พบปลายทางที่เลือก");
      return;
    }

    this.destinationNodeId = destinationId;
    this.currentRoute = this.router.findPath(this.startNodeId, this.destinationNodeId);

    if (!this.currentRoute || !this.currentRoute.steps.length) {
      alert("ขออภัย ไม่พบเส้นทางเชื่อมต่อระหว่างสองจุดนี้");
      return;
    }

    this.currentStepIndex = 0;

    // แสดงหน้าจอการนำทาง (ซ่อนหน้าค้นหา)
    document.getElementById('screen-home').classList.add('hidden');
    document.getElementById('screen-navigation').classList.remove('hidden');

    window.scrollTo({ top: 0, behavior: 'smooth' });

    // แสดงข้อมูลภาพรวมเส้นทาง
    const destNode = this.data.nodes[this.destinationNodeId];
    document.getElementById('nav-destination-title').textContent = destNode.name;
    document.getElementById('nav-total-info').textContent = 
      `ระยะทางรวม ~${this.currentRoute.totalDistance} เมตร (เดินประมาณ ${this.currentRoute.estimatedTimeMinutes} นาที)`;

    this.renderCurrentStep();
    this.renderMapRoute();
  }

  // แสดงผลขั้นตอนปัจจุบัน
  renderCurrentStep() {
    if (!this.currentRoute) return;

    const steps = this.currentRoute.steps;
    const currentStep = steps[this.currentStepIndex];
    const totalSteps = steps.length;

    document.getElementById('step-counter').textContent = `ขั้นตอนที่ ${this.currentStepIndex + 1} จาก ${totalSteps}`;
    const progressPercent = ((this.currentStepIndex + 1) / totalSteps) * 100;
    document.getElementById('step-progress-bar').style.width = `${progressPercent}%`;

    const instructionElem = document.getElementById('step-instruction');
    instructionElem.textContent = currentStep.instruction;

    const landmarkElem = document.getElementById('step-landmark');
    if (currentStep.landmarkNotice) {
      landmarkElem.innerHTML = `<strong>จุดสังเกต:</strong> ${currentStep.landmarkNotice}`;
      landmarkElem.parentElement.classList.remove('hidden');
    } else {
      landmarkElem.parentElement.classList.add('hidden');
    }

    const arrowElem = document.getElementById('step-arrow-icon');
    arrowElem.innerHTML = this.getArrowHtml(currentStep.arrow);

    const stepDistanceElem = document.getElementById('step-distance-badge');
    if (currentStep.distance > 0) {
      stepDistanceElem.textContent = `เดินอีก ${currentStep.distance} ม.`;
      stepDistanceElem.classList.remove('hidden');
    } else {
      stepDistanceElem.classList.add('hidden');
    }

    const btnPrev = document.getElementById('btn-prev-step');
    const btnNext = document.getElementById('btn-next-step');

    if (this.currentStepIndex === 0) {
      btnPrev.classList.add('opacity-40', 'cursor-not-allowed');
      btnPrev.disabled = true;
    } else {
      btnPrev.classList.remove('opacity-40', 'cursor-not-allowed');
      btnPrev.disabled = false;
    }

    if (this.currentStepIndex === totalSteps - 1) {
      btnNext.innerHTML = `<span>🎉 เสร็จสิ้น</span>`;
      btnNext.className = "flex-1 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all";
    } else {
      btnNext.innerHTML = `<span>ก้าวต่อไป (${this.currentStepIndex + 2}/${totalSteps})</span> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>`;
      btnNext.className = "flex-1 py-4 px-6 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all";
    }

    this.displayStepPhoto(currentStep);

    if (this.isVoiceEnabled) {
      this.speakText(currentStep.audioText || currentStep.instruction);
    }

    const currentFloor = currentStep.toNode.floor || "floor1";
    this.changeMapFloor(currentFloor, false);
    this.highlightMapCurrentLocation(currentStep.toNode);
  }

  // จัดการโหลดรูปหรือ Fallback SVG เมื่อยังไม่มีรูปจริง
  displayStepPhoto(step) {
    const photoContainer = document.getElementById('step-photo-container');
    if (!photoContainer) return;

    const imgElem = document.createElement('img');
    imgElem.alt = step.toNode.name;
    imgElem.className = "w-full h-full object-cover transition-opacity duration-300";

    imgElem.onerror = () => {
      photoContainer.innerHTML = this.generateFallbackPhotoSvg(step);
    };

    imgElem.src = step.photo || step.toNode.photo;
    photoContainer.innerHTML = '';
    photoContainer.appendChild(imgElem);

    const overlay = document.createElement('div');
    overlay.className = "photo-overlay-badge";
    overlay.innerHTML = `
      <div class="p-2 bg-sky-600 rounded-lg text-white font-bold text-sm">
        ${step.toNode.floor === 'floor1' ? 'ชั้น 1' : 'ชั้น 2'}
      </div>
      <div class="flex-1 truncate">
        <div class="text-xs text-sky-200">เป้าหมายขั้นตอนนี้</div>
        <div class="text-sm font-bold truncate">${step.toNode.name}</div>
      </div>
    `;
    photoContainer.appendChild(overlay);
  }

  generateFallbackPhotoSvg(step) {
    const isDest = step.isDestination;
    const arrowSymbol = this.getArrowTextSymbol(step.arrow);
    const bgColor = isDest ? "#065f46" : "#0f172a";
    const accentColor = isDest ? "#10b981" : "#0284c7";

    return `
      <div class="photo-placeholder" style="background: radial-gradient(circle at center, ${accentColor}22 0%, ${bgColor} 100%);">
        <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-3 shadow-inner">
          <span class="text-4xl">${isDest ? '🏁' : arrowSymbol}</span>
        </div>
        <div class="text-xs uppercase tracking-wider text-sky-300 font-semibold mb-1">
          ${isDest ? '✨ ปลายทางของคุณ' : 'มุมมองจำลองทางเดิน'}
        </div>
        <h4 class="text-xl font-bold text-white max-w-sm px-4 leading-tight mb-2">
          ${step.toNode.name}
        </h4>
        <p class="text-xs text-slate-300 max-w-xs px-2 line-clamp-2">
          📍 ${step.landmarkNotice || step.instruction}
        </p>
        <div class="mt-4 inline-block px-3 py-1 bg-white/15 rounded-full text-xs text-white/90">
          (ภาพถ่ายจริงจะแสดง ณ จุดนี้)
        </div>
      </div>
    `;
  }

  nextStep() {
    if (!this.currentRoute) return;

    if (this.currentStepIndex < this.currentRoute.steps.length - 1) {
      this.currentStepIndex++;
      this.renderCurrentStep();
      window.scrollTo({ top: 120, behavior: 'smooth' });
    } else {
      alert("🎉 คุณเดินทางถึงที่หมายเรียบร้อยแล้ว หากต้องการนำทางใหม่ สามารถกดเลือกสถานที่ได้เลยค่ะ");
      this.cancelNavigation();
    }
  }

  prevStep() {
    if (!this.currentRoute) return;

    if (this.currentStepIndex > 0) {
      this.currentStepIndex--;
      this.renderCurrentStep();
      window.scrollTo({ top: 120, behavior: 'smooth' });
    }
  }

  cancelNavigation() {
    if (this.speechSynthesis) {
      this.speechSynthesis.cancel();
    }
    this.currentRoute = null;
    this.destinationNodeId = null;
    document.getElementById('screen-navigation').classList.add('hidden');
    document.getElementById('screen-home').classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  switchView(viewType) {
    this.activeView = viewType;
    const photoContainer = document.getElementById('view-photo-container');
    const mapContainer = document.getElementById('view-map-container');
    const btnPhoto = document.getElementById('btn-view-photo');
    const btnMap = document.getElementById('btn-view-map');

    if (viewType === 'photo') {
      photoContainer.classList.remove('hidden');
      mapContainer.classList.add('hidden');
      btnPhoto.className = "flex-1 py-2.5 px-4 rounded-xl font-bold text-sm bg-sky-600 text-white shadow-sm flex items-center justify-center gap-2";
      btnMap.className = "flex-1 py-2.5 px-4 rounded-xl font-bold text-sm bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center gap-2";
    } else {
      photoContainer.classList.add('hidden');
      mapContainer.classList.remove('hidden');
      btnPhoto.className = "flex-1 py-2.5 px-4 rounded-xl font-bold text-sm bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center gap-2";
      btnMap.className = "flex-1 py-2.5 px-4 rounded-xl font-bold text-sm bg-sky-600 text-white shadow-sm flex items-center justify-center gap-2";
      this.renderMapRoute();
    }
  }

  changeMapFloor(floorId, rerender = true) {
    this.currentMapFloor = floorId;
    const floor1Frame = document.getElementById('floor1-svg-frame');
    const floor2Frame = document.getElementById('floor2-svg-frame');
    const btnFloor1 = document.getElementById('map-btn-floor1');
    const btnFloor2 = document.getElementById('map-btn-floor2');

    if (floorId === 'floor1') {
      if (floor1Frame) floor1Frame.classList.remove('hidden');
      if (floor2Frame) floor2Frame.classList.add('hidden');
      if (btnFloor1) btnFloor1.className = "px-3 py-1.5 rounded-lg text-xs font-bold bg-sky-600 text-white";
      if (btnFloor2) btnFloor2.className = "px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-200 text-slate-700";
    } else {
      if (floor1Frame) floor1Frame.classList.add('hidden');
      if (floor2Frame) floor2Frame.classList.remove('hidden');
      if (btnFloor1) btnFloor1.className = "px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-200 text-slate-700";
      if (btnFloor2) btnFloor2.className = "px-3 py-1.5 rounded-lg text-xs font-bold bg-sky-600 text-white";
    }

    if (rerender) {
      this.renderMapRoute();
    }
  }

  renderMapRoute() {
    if (!this.currentRoute) return;

    ['floor1', 'floor2'].forEach(floorId => {
      const containerId = floorId === 'floor1' ? 'dynamic-route-layer' : 'dynamic-route-layer-2';
      const layer = document.getElementById(containerId);
      if (!layer) return;

      layer.innerHTML = '';

      const floorNodes = this.currentRoute.pathNodes.filter(n => n.floor === floorId);

      if (floorNodes.length >= 2) {
        let pathD = `M ${floorNodes[0].x} ${floorNodes[0].y}`;
        for (let i = 1; i < floorNodes.length; i++) {
          pathD += ` L ${floorNodes[i].x} ${floorNodes[i].y}`;
        }

        const pathElem = document.createElementNS("http://www.w3.org/2000/svg", "path");
        pathElem.setAttribute("d", pathD);
        pathElem.setAttribute("fill", "none");
        pathElem.setAttribute("stroke", "#0284c7");
        pathElem.setAttribute("stroke-width", "8");
        pathElem.setAttribute("stroke-dasharray", "10 6");
        pathElem.setAttribute("stroke-linecap", "round");
        pathElem.setAttribute("stroke-linejoin", "round");
        layer.appendChild(pathElem);
      }

      floorNodes.forEach((node) => {
        const isStart = (node.id === this.startNodeId);
        const isEnd = (node.id === this.destinationNodeId);
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", node.x);
        circle.setAttribute("cy", node.y);
        circle.setAttribute("r", isStart || isEnd ? "14" : "8");
        circle.setAttribute("fill", isStart ? "#10b981" : (isEnd ? "#ef4444" : "#0284c7"));
        circle.setAttribute("stroke", "#ffffff");
        circle.setAttribute("stroke-width", "3");
        layer.appendChild(circle);
      });
    });
  }

  highlightMapCurrentLocation(node) {}

  // ทำความสะอาดข้อความ ตัดอีโมจิและสัญลักษณ์ที่อ่านไม่ออก
  cleanTextForSpeech(text) {
    if (!text) return "";
    return text
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .replace(/⚠️|📍|👁️|🔊|🛗|⬆️|⬇️|⬅️|➡️|🏁|💓|💊|🩸|🩻|🩺|🦴|📋|🚻/g, '')
      .replace(/~/g, 'ประมาณ ')
      .replace(/ม\./g, 'เมตร')
      .trim();
  }

  // ระบบอ่านออกเสียงภาษาไทย (Dual Engine: Web Speech API + Audio Stream Fallback)
  speakText(text) {
    const cleanSpeech = this.cleanTextForSpeech(text);
    if (!cleanSpeech) return;

    const speakerBtn = document.getElementById('btn-speak-again');
    if (speakerBtn) {
      speakerBtn.classList.add('speaking-ripple');
    }

    // หยุดเสียงเดิมที่กำลังเล่นอยู่
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch (e) {}
    }
    if (this.speechSynthesis) {
      try {
        this.speechSynthesis.cancel();
      } catch (e) {}
    }

    // เช็คว่ามี Thai Voice ใน Web Speech API หรือไม่
    if (this.speechSynthesis && this.thaiVoice) {
      try {
        const utterance = new SpeechSynthesisUtterance(cleanSpeech);
        utterance.voice = this.thaiVoice;
        utterance.lang = 'th-TH';
        utterance.rate = 0.95;
        utterance.pitch = 1.0;

        let hasSpoken = false;
        utterance.onstart = () => { hasSpoken = true; };
        utterance.onend = () => {
          if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
        };
        utterance.onerror = (err) => {
          console.warn('SpeechSynthesis error, falling back to Audio TTS:', err);
          if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
          this.fallbackAudioTTS(cleanSpeech);
        };

        this.speechSynthesis.speak(utterance);

        // เช็คเผื่อกรณีเบราว์เซอร์ไม่ยิง onstart (เช่น ติด autoplay block หรือ bug) ภายใน 800ms
        setTimeout(() => {
          if (!hasSpoken && this.speechSynthesis.speaking === false) {
            this.fallbackAudioTTS(cleanSpeech);
          }
        }, 800);

        return;
      } catch (err) {
        console.warn('SpeechSynthesis exception:', err);
      }
    }

    // หากไม่มี Thai Voice ในเครื่อง หรือ Web Speech API ล้มเหลว -> ใช้ Fallback Audio
    this.fallbackAudioTTS(cleanSpeech);
  }

  // สตรีมเสียงภาษาไทยออนไลน์ผ่าน HTML5 Audio (รับประกันมีเสียงพูดภาษาไทย 100%)
  fallbackAudioTTS(cleanText) {
    const speakerBtn = document.getElementById('btn-speak-again');
    try {
      const encodedText = encodeURIComponent(cleanText);
      const audioUrl = `https://translate.google.com/translate_tts?ie=UTF-8&tl=th&client=tw-ob&q=${encodedText}`;
      
      const audio = new Audio(audioUrl);
      this.currentAudio = audio;

      audio.onended = () => {
        if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
      };
      audio.onerror = () => {
        if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
        console.warn('Audio TTS could not play');
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(error => {
          console.warn('Audio play prevented by browser autoplay policy:', error);
          if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
        });
      }
    } catch (e) {
      if (speakerBtn) speakerBtn.classList.remove('speaking-ripple');
      console.warn('Fallback Audio Error:', e);
    }
  }

  speakCurrentStep() {
    if (!this.currentRoute) return;
    const currentStep = this.currentRoute.steps[this.currentStepIndex];
    this.speakText(currentStep.audioText || currentStep.instruction);
  }

  applyFontSize(level) {
    this.fontSizeLevel = level;
    document.body.classList.remove('font-size-large', 'font-size-xlarge');

    const btnNormal = document.getElementById('btn-font-normal');
    const btnLarge = document.getElementById('btn-font-large');
    const btnXLarge = document.getElementById('btn-font-xlarge');

    [btnNormal, btnLarge, btnXLarge].forEach(b => {
      if (b) b.classList.remove('bg-sky-600', 'text-white', 'border-sky-600');
    });

    if (level === 'large') {
      document.body.classList.add('font-size-large');
      if (btnLarge) btnLarge.classList.add('bg-sky-600', 'text-white');
    } else if (level === 'xlarge') {
      document.body.classList.add('font-size-xlarge');
      if (btnXLarge) btnXLarge.classList.add('bg-sky-600', 'text-white');
    } else {
      if (btnNormal) btnNormal.classList.add('bg-sky-600', 'text-white');
    }
  }

  getArrowHtml(arrowType) {
    switch (arrowType) {
      case 'straight':
        return `<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>`;
      case 'turn-left':
        return `<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>`;
      case 'turn-right':
        return `<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>`;
      case 'slight-left':
        return `<svg class="w-8 h-8 transform -rotate-45" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>`;
      case 'slight-right':
        return `<svg class="w-8 h-8 transform rotate-45" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>`;
      case 'up-elevator':
        return `<span class="text-2xl font-bold">🛗 ⬆️</span>`;
      case 'down-elevator':
        return `<span class="text-2xl font-bold">🛗 ⬇️</span>`;
      case 'arrived':
        return `<span class="text-2xl">🏁</span>`;
      default:
        return `<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>`;
    }
  }

  getArrowTextSymbol(arrowType) {
    switch (arrowType) {
      case 'straight': return '⬆️';
      case 'turn-left': return '⬅️';
      case 'turn-right': return '➡️';
      case 'slight-left': return '↖️';
      case 'slight-right': return '↗️';
      case 'up-elevator': return '🛗⬆️';
      case 'down-elevator': return '🛗⬇️';
      case 'arrived': return '🏁';
      default: return '⬆️';
    }
  }

  openQrSelectorModal() {
    const modal = document.getElementById('qr-simulate-modal');
    if (!modal) return;
    modal.classList.remove('hidden');

    const listContainer = document.getElementById('qr-points-list');
    listContainer.innerHTML = '';

    Object.values(this.data.nodes).forEach(node => {
      const btn = document.createElement('button');
      btn.className = "w-full text-left p-3 rounded-xl border border-slate-200 hover:bg-sky-50 hover:border-sky-400 flex items-center justify-between";
      btn.innerHTML = `
        <div>
          <div class="font-bold text-slate-800 text-sm">${node.name}</div>
          <div class="text-xs text-slate-500">${node.landmark}</div>
        </div>
        <span class="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700 font-semibold">${node.floor === 'floor1' ? 'ชั้น 1' : 'ชั้น 2'}</span>
      `;
      btn.addEventListener('click', () => {
        this.startNodeId = node.id;
        this.updateStartPointDisplay();
        const startSelect = document.getElementById('start-location-select');
        if (startSelect) startSelect.value = node.id;
        modal.classList.add('hidden');
        this.showToast(`📷 สแกนสำเร็จ! จุดของคุณคือ: ${node.name}`);
        if (this.destinationNodeId) {
          this.startNavigation(this.destinationNodeId);
        }
      });
      listContainer.appendChild(btn);
    });

    const closeBtn = document.getElementById('btn-close-qr-modal');
    if (closeBtn) closeBtn.onclick = () => modal.classList.add('hidden');
  }

  showToast(message) {
    const toast = document.createElement('div');
    toast.className = "fixed top-20 left-1/2 transform -translate-x-1/2 bg-slate-900/90 text-white px-5 py-2.5 rounded-full text-sm font-semibold shadow-xl z-50 backdrop-blur-sm transition-all";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }
}

// เริ่มต้นแอปเมื่อโหลดหน้าเว็บเสร็จ
document.addEventListener('DOMContentLoaded', () => {
  window.app = new HospitalApp();
});
