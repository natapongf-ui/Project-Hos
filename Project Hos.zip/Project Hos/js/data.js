/**
 * ข้อมูลแผนผังและจุดนำทาง โรงพยาบาลสวรรค์ประชารักษ์ (เขาเขียว)
 * สถาปัตยกรรมข้อมูล: กราฟ (Nodes & Edges) สำหรับการหาเส้นทางเดิน
 */

const HOSPITAL_DATA = {
  hospitalName: "โรงพยาบาลสวรรค์ประชารักษ์ (เขาเขียว)",
  appName: "SPK Smart Wayfinding (นำทางเขาเขียว)",
  version: "1.0.0",

  // รายการชั้นในอาคารผู้ป่วยนอก (OPD)
  floors: [
    { id: "floor1", name: "ชั้น 1", description: "จุดคัดกรอง, เวชระเบียน, เจาะเลือด, การเงิน, ห้องยา" },
    { id: "floor2", name: "ชั้น 2", description: "ห้องตรวจอายุรกรรม, ศัลยกรรม, เอกซเรย์ (X-Ray)" },
    { id: "floor3", name: "ชั้น 3", description: "คลินิกตา หู คอ จมูก, ทันตกรรม" }
  ],

  // หมวดหมู่ปลายทางด่วน (เหมาะกับผู้สูงอายุ กดง่าย ไอคอนชัด)
  quickCategories: [
    { id: "blood", title: "เจาะเลือด / แล็บ", icon: "🩸", targetNode: "lab_blood", color: "bg-red-500", floor: "ชั้น 1" },
    { id: "pharmacy", title: "รับยา / การเงิน", icon: "💊", targetNode: "pharmacy", color: "bg-emerald-600", floor: "ชั้น 1" },
    { id: "xray", title: "เอกซเรย์ (X-Ray)", icon: "🩻", targetNode: "xray", color: "bg-blue-600", floor: "ชั้น 2" },
    { id: "med_clinic", title: "ตรวจอายุรกรรม", icon: "🩺", targetNode: "clinic_med", color: "bg-purple-600", floor: "ชั้น 2" },
    { id: "surgery", title: "ศัลยกรรม / กระดูก", icon: "🦴", targetNode: "clinic_surgery", color: "bg-amber-600", floor: "ชั้น 2" },
    { id: "records", title: "ทำบัตร / เวชระเบียน", icon: "📋", targetNode: "records", color: "bg-teal-600", floor: "ชั้น 1" },
    { id: "restroom", title: "ห้องน้ำที่ใกล้ที่สุด", icon: "🚻", targetNode: "wc_floor1", color: "bg-indigo-500", floor: "ชั้น 1/2" },
    { id: "screening", title: "จุดคัดกรอง / วัดความดัน", icon: "💓", targetNode: "screening", color: "bg-rose-600", floor: "ชั้น 1" }
  ],

  // จุดอ้างอิงทั้งหมดในอาคาร (Nodes)
  nodes: {
    // === ชั้น 1 ===
    "entrance_1": {
      id: "entrance_1",
      name: "ประตูทางเข้าหลัก อาคาร OPD (ชั้น 1)",
      shortName: "ทางเข้าหลัก",
      floor: "floor1",
      floorNumber: 1,
      type: "entrance",
      isStartPoint: true,
      x: 120, // พิกัดจำลองบน SVG Map
      y: 450,
      description: "จุดลงรถ ประตูทางเข้าด้านหน้าอาคารผู้ป่วยนอก",
      photo: "images/routes/entrance_1.jpg",
      landmark: "ซุ้มประตูทางเข้าหลัก มีเจ้าหน้าที่เวรเปลคอยบริการ"
    },
    "screening": {
      id: "screening",
      name: "จุดคัดกรอง & วัดความดัน (ชั้น 1)",
      shortName: "จุดคัดกรอง",
      floor: "floor1",
      floorNumber: 1,
      type: "screening",
      isStartPoint: true,
      x: 220,
      y: 380,
      description: "จุดวัดความดัน ชั่งน้ำหนัก และคัดกรองอาการเบื้องต้น",
      photo: "images/routes/screening.jpg",
      landmark: "โต๊ะพยาบาลคัดกรองและเครื่องวัดความดันอัตโนมัติ"
    },
    "records": {
      id: "records",
      name: "ห้องเวชระเบียน / จุดทำบัตรใหม่ (ชั้น 1)",
      shortName: "เวชระเบียน / ทำบัตร",
      floor: "floor1",
      floorNumber: 1,
      type: "service",
      x: 340,
      y: 430,
      description: "จุดตรวจสอบสิทธิการรักษา บัตรทอง ประกันสังคม ทำประวัติใหม่",
      photo: "images/routes/records.jpg",
      landmark: "ช่องบริการกระจกใส มีป้ายเขียนว่า 'เวชระเบียนและทำบัตร'"
    },
    "hall_center_1": {
      id: "hall_center_1",
      name: "โถงทางเดินกลาง อาคาร OPD (ชั้น 1)",
      shortName: "โถงกลาง ชั้น 1",
      floor: "floor1",
      floorNumber: 1,
      type: "junction",
      isStartPoint: true,
      x: 380,
      y: 320,
      description: "ลานโถงทางเดินหลัก เชื่อมต่อไปห้องยา ห้องเจาะเลือด และลิฟต์",
      photo: "images/routes/hall_center_1.jpg",
      landmark: "เสากลางโถง มีจอแสดงคิวส่วนกลางและป้ายบอกทางขนาดใหญ่"
    },
    "lab_blood": {
      id: "lab_blood",
      name: "ห้องเจาะเลือด & ตรวจทางห้องปฏิบัติการ (ชั้น 1)",
      shortName: "ห้องเจาะเลือด",
      floor: "floor1",
      floorNumber: 1,
      type: "lab",
      x: 520,
      y: 200,
      description: "ห้องตรวจเลือดและส่งตรวจปัสสาวะ/อุจจาระ",
      photo: "images/routes/lab_blood.jpg",
      landmark: "ตู้กดบัตรคิวเจาะเลือดและเก้าอี้พักคอยสีฟ้า"
    },
    "pharmacy": {
      id: "pharmacy",
      name: "ห้องจ่ายยา & จุดชำระเงิน (ชั้น 1)",
      shortName: "ห้องจ่ายยา / การเงิน",
      floor: "floor1",
      floorNumber: 1,
      type: "pharmacy",
      x: 580,
      y: 380,
      description: "ช่องรับยา ช่องชำระค่ารักษาพยาบาล และตู้พักคอยรับยา",
      photo: "images/routes/pharmacy.jpg",
      landmark: "ช่องกระจกยาวเบอร์ 1-8 ด้านบนมีจอเรียกคิวรับยา"
    },
    "elevator_1": {
      id: "elevator_1",
      name: "โถงลิฟต์โดยสาร ชั้น 1",
      shortName: "ลิฟต์โดยสาร ชั้น 1",
      floor: "floor1",
      floorNumber: 1,
      type: "elevator",
      isStartPoint: true,
      x: 380,
      y: 180,
      description: "ลิฟต์โดยสารสำหรับขึ้นชั้น 2, 3, 4",
      photo: "images/routes/elevator_1.jpg",
      landmark: "หน้าลิฟต์ 3 ตัว มีป้ายบอกทางขึ้นชั้น 2-4"
    },
    "wc_floor1": {
      id: "wc_floor1",
      name: "ห้องน้ำชาย-หญิง & ผู้พิการ (ชั้น 1)",
      shortName: "ห้องน้ำ ชั้น 1",
      floor: "floor1",
      floorNumber: 1,
      type: "wc",
      x: 200,
      y: 180,
      description: "ห้องน้ำสาธารณะชั้น 1 ใกล้ทางเข้า",
      photo: "images/routes/wc_floor1.jpg",
      landmark: "ป้ายห้องน้ำสีน้ำเงิน มีทางลาดสำหรับรถเข็น"
    },

    // === ชั้น 2 ===
    "elevator_2": {
      id: "elevator_2",
      name: "โถงลิฟต์โดยสาร ชั้น 2",
      shortName: "ลิฟต์โดยสาร ชั้น 2",
      floor: "floor2",
      floorNumber: 2,
      type: "elevator",
      isStartPoint: true,
      x: 380,
      y: 180,
      description: "จุดออกจากลิฟต์ชั้น 2 เพื่อไปคลินิกตรวจต่างๆ",
      photo: "images/routes/elevator_2.jpg",
      landmark: "หน้าประตูลิฟต์ชั้น 2 ออกมาจะเจอป้ายแผนกอายุรกรรมและเอกซเรย์"
    },
    "vital_signs_2": {
      id: "vital_signs_2",
      name: "จุดคัดกรอง & วัดความดันก่อนเข้าตรวจ (ชั้น 2)",
      shortName: "จุดวัดความดัน ชั้น 2",
      floor: "floor2",
      floorNumber: 2,
      type: "screening",
      x: 380,
      y: 270,
      description: "จุดตรวจสัญญาณชีพและลงทะเบียนหน้าห้องตรวจ",
      photo: "images/routes/vital_signs_2.jpg",
      landmark: "เคาน์เตอร์พยาบาลกลางชั้น 2"
    },
    "clinic_med": {
      id: "clinic_med",
      name: "คลินิกอายุรกรรม (ห้องตรวจ 201 - 208)",
      shortName: "คลินิกอายุรกรรม",
      floor: "floor2",
      floorNumber: 2,
      type: "clinic",
      x: 230,
      y: 350,
      description: "ตรวจรักษาโรคทั่วไป ความดัน เบาหวาน โรคหัวใจ ระบบทางเดินหายใจ",
      photo: "images/routes/clinic_med.jpg",
      landmark: "โซนเก้าอี้สีเขียว มีป้าย 'คลินิกอายุรกรรม ห้องตรวจ 201-208'"
    },
    "clinic_surgery": {
      id: "clinic_surgery",
      name: "คลินิกศัลยกรรม & กระดูกและข้อ (ห้องตรวจ 209 - 215)",
      shortName: "ศัลยกรรม / กระดูก",
      floor: "floor2",
      floorNumber: 2,
      type: "clinic",
      x: 540,
      y: 350,
      description: "ตรวจแผล ผ่าตัดเล็ก ตรวจกระดูก ปวดข้อ ใส่เฝือก",
      photo: "images/routes/clinic_surgery.jpg",
      landmark: "โซนห้องตรวจปีกขวา มีห้องทำแผลและห้องใส่เฝือก"
    },
    "xray": {
      id: "xray",
      name: "แผนกรังสีวินิจฉัย / ห้องเอกซเรย์ (X-Ray)",
      shortName: "ห้องเอกซเรย์ (X-Ray)",
      floor: "floor2",
      floorNumber: 2,
      type: "xray",
      x: 560,
      y: 180,
      description: "ห้องถ่ายภาพรังสีทรวงอก กระดูก CT-Scan",
      photo: "images/routes/xray.jpg",
      landmark: "ป้ายไฟเตือนสีแดงหน้าห้องเอกซเรย์ 'ระวังรังสี ห้ามเข้าขณะไฟสว่าง'"
    },
    "wc_floor2": {
      id: "wc_floor2",
      name: "ห้องน้ำ ชั้น 2",
      shortName: "ห้องน้ำ ชั้น 2",
      floor: "floor2",
      floorNumber: 2,
      type: "wc",
      x: 200,
      y: 180,
      description: "ห้องน้ำสาธารณะชั้น 2 ปีกซ้าย",
      photo: "images/routes/wc_floor2.jpg",
      landmark: "ทางเดินปีกซ้ายติดกับคลินิกอายุรกรรม"
    }
  },

  // เส้นทางเชื่อมระหว่างจุด (Edges)
  // แต่ละเส้นทางจะมี: คำอธิบาย, รูปภาพ, ทิศทางลูกศร, ระยะทางเมตร
  edges: [
    // --- ชั้น 1: ทางเข้า -> จุดคัดกรอง ---
    {
      from: "entrance_1",
      to: "screening",
      distance: 15,
      instruction: "เดินตรงเข้าประตูอาคาร แล้วเลี้ยวซ้ายเล็กน้อยไปยังจุดคัดกรอง",
      arrow: "straight",
      landmarkNotice: "สังเกตโต๊ะพยาบาลและเครื่องวัดความดันสีขาว",
      audioText: "เดินตรงเข้าประตูอาคาร แล้วเบี่ยงซ้ายเล็กน้อยเพื่อไปยังจุดคัดกรองและวัดความดันค่ะ"
    },
    {
      from: "screening",
      to: "entrance_1",
      distance: 15,
      instruction: "เดินตรงออกไปยังประตูทางเข้าหลัก",
      arrow: "straight",
      landmarkNotice: "ประตูทางออกหลักด้านหน้า",
      audioText: "เดินตรงไปทางประตูทางออกหลักค่ะ"
    },

    // --- ชั้น 1: จุดคัดกรอง -> เวชระเบียน ---
    {
      from: "screening",
      to: "records",
      distance: 20,
      instruction: "จากจุดคัดกรอง หันไปทางขวา เดินตรงไปที่ช่องทำบัตรและเวชระเบียน",
      arrow: "turn-right",
      landmarkNotice: "ช่องบริการกระจกใส มีป้าย 'เวชระเบียนและทำบัตร'",
      audioText: "เลี้ยวขวาแล้วเดินตรงไป 20 เมตร จะถึงช่องเวชระเบียนเพื่อทำบัตรค่ะ"
    },
    {
      from: "records",
      to: "screening",
      distance: 20,
      instruction: "เดินย้อนกลับมาทางซ้าย เพื่อไปยังจุดคัดกรอง",
      arrow: "turn-left",
      landmarkNotice: "โต๊ะคัดกรองและวัดความดัน",
      audioText: "เดินไปทางซ้ายกลับมาที่จุดคัดกรองค่ะ"
    },

    // --- ชั้น 1: จุดคัดกรอง -> โถงกลาง ---
    {
      from: "screening",
      to: "hall_center_1",
      distance: 25,
      instruction: "เดินตรงผ่านจุดคัดกรองเข้าสู่โถงทางเดินกลางอาคาร",
      arrow: "straight",
      landmarkNotice: "เสากลางโถง มีจอทีวีบอกหมายเลขคิว",
      audioText: "เดินตรงไปตามทางเดินหลัก 25 เมตร เข้าสู่โถงกลางอาคารค่ะ"
    },
    {
      from: "hall_center_1",
      to: "screening",
      distance: 25,
      instruction: "เดินตรงกลับมาทางประตูทางเข้า จะพบจุดคัดกรองอยู่ทางขวามือ",
      arrow: "straight",
      landmarkNotice: "จุดคัดกรองวัดความดัน",
      audioText: "เดินตรงกลับมาทางประตูทางเข้า จะพบจุดคัดกรองค่ะ"
    },

    // --- ชั้น 1: เวชระเบียน -> โถงกลาง ---
    {
      from: "records",
      to: "hall_center_1",
      distance: 18,
      instruction: "เดินออกจากช่องเวชระเบียนแล้วเลี้ยวซ้ายเข้าสู่โถงกลาง",
      arrow: "turn-left",
      landmarkNotice: "เสากลางโถงทางเดิน",
      audioText: "เลี้ยวซ้ายเดินเข้าสู่โถงกลางอาคารค่ะ"
    },
    {
      from: "hall_center_1",
      to: "records",
      distance: 18,
      instruction: "จากโถงกลาง เดินเลี้ยวขวาไปยังเคาน์เตอร์เวชระเบียน",
      arrow: "turn-right",
      landmarkNotice: "ช่องบริการกระจกใส",
      audioText: "เลี้ยวขวาไปยังเคาน์เตอร์เวชระเบียนค่ะ"
    },

    // --- ชั้น 1: โถงกลาง -> ห้องเจาะเลือด ---
    {
      from: "hall_center_1",
      to: "lab_blood",
      distance: 30,
      instruction: "จากโถงกลาง เดินเฉียงไปทางขวาบนตามป้าย 'ห้องเจาะเลือด'",
      arrow: "slight-right",
      landmarkNotice: "หน้าห้องมีตู้กดบัตรคิวเจาะเลือดและเก้าอี้สีฟ้า",
      audioText: "เดินเฉียงขวาตรงไป 30 เมตร จะถึงห้องเจาะเลือด กดบัตรคิวด้านหน้าห้องได้เลยค่ะ"
    },
    {
      from: "lab_blood",
      to: "hall_center_1",
      distance: 30,
      instruction: "เดินออกจากห้องเจาะเลือด ตรงกลับเข้าสู่โถงกลางอาคาร",
      arrow: "straight",
      landmarkNotice: "โถงกลางอาคาร",
      audioText: "เดินตรงออกจากห้องเจาะเลือดเพื่อกลับมาที่โถงกลางค่ะ"
    },

    // --- ชั้น 1: โถงกลาง -> ห้องยา & การเงิน ---
    {
      from: "hall_center_1",
      to: "pharmacy",
      distance: 25,
      instruction: "จากโถงกลาง เลี้ยวขวาเดินตรงไปตามทาง จะพบช่องจ่ายยาและการเงิน",
      arrow: "turn-right",
      landmarkNotice: "ช่องจ่ายยาเบอร์ 1-8 และจอแสดงคิวรับยา",
      audioText: "เลี้ยวขวาเดินตรงไป 25 เมตร จะพบห้องจ่ายยาและจุดชำระเงินค่ะ"
    },
    {
      from: "pharmacy",
      to: "hall_center_1",
      distance: 25,
      instruction: "เดินย้อนกลับมาทางซ้าย เข้าสู่โถงกลางอาคาร",
      arrow: "turn-left",
      landmarkNotice: "โถงทางเดินกลาง",
      audioText: "เลี้ยวซ้ายเดินกลับมายังโถงกลางค่ะ"
    },

    // --- ชั้น 1: โถงกลาง -> ลิฟต์โดยสาร ชั้น 1 ---
    {
      from: "hall_center_1",
      to: "elevator_1",
      distance: 20,
      instruction: "จากโถงกลาง เดินตรงลึกเข้าไป จะพบโถงลิฟต์โดยสารอยู่ตรงหน้า",
      arrow: "straight",
      landmarkNotice: "ลิฟต์โดยสาร 3 ช่อง มีปุ่มกดขึ้นชั้น 2-4",
      audioText: "เดินตรงไป 20 เมตร จะถึงโถงลิฟต์โดยสาร กดลิฟต์ขึ้นชั้น 2 ได้เลยค่ะ"
    },
    {
      from: "elevator_1",
      to: "hall_center_1",
      distance: 20,
      instruction: "ออกจากลิฟต์ เดินตรงไปข้างหน้าจะเข้าสู่โถงกลางอาคาร",
      arrow: "straight",
      landmarkNotice: "โถงกลางอาคาร ชั้น 1",
      audioText: "เดินออกจากลิฟต์ตรงไปข้างหน้าเข้าสู่โถงกลางค่ะ"
    },

    // --- ชั้น 1: โถงกลาง -> ห้องน้ำ ชั้น 1 ---
    {
      from: "hall_center_1",
      to: "wc_floor1",
      distance: 28,
      instruction: "จากโถงกลาง เลี้ยวซ้ายเดินไปตามทางเดิน จะพบห้องน้ำอยู่ทางซ้ายมือ",
      arrow: "turn-left",
      landmarkNotice: "ป้ายห้องน้ำสีน้ำเงิน มีทางลาดคนพิการ",
      audioText: "เลี้ยวซ้ายเดินตรงไปตามทางเดิน 28 เมตร ห้องน้ำจะอยู่ทางซ้ายมือค่ะ"
    },
    {
      from: "wc_floor1",
      to: "hall_center_1",
      distance: 28,
      instruction: "ออกจากห้องน้ำ เดินตรงกลับเข้าสู่โถงกลาง",
      arrow: "straight",
      landmarkNotice: "โถงกลางอาคาร",
      audioText: "เดินตรงกลับเข้ามาที่โถงกลางอาคารค่ะ"
    },

    // --- ลิฟต์: ชั้น 1 <-> ชั้น 2 ---
    {
      from: "elevator_1",
      to: "elevator_2",
      distance: 10,
      instruction: "เข้าลิฟต์โดยสาร กดปุ่มชั้น 2 เมื่อถึงชั้น 2 ประตูลิฟต์เปิดให้ก้าวออก",
      arrow: "up-elevator",
      landmarkNotice: "ประตูลิฟต์เปิดออกสู่ชั้น 2 อาคารผู้ป่วยนอก",
      audioText: "เข้าลิฟต์แล้วกดปุ่มชั้น 2 นะคะ เมื่อถึงแล้วเดินออกจากลิฟต์ได้เลยค่ะ"
    },
    {
      from: "elevator_2",
      to: "elevator_1",
      distance: 10,
      instruction: "เข้าลิฟต์โดยสาร กดปุ่มชั้น 1 เพื่อลงไปยังชั้นล่างสุด",
      arrow: "down-elevator",
      landmarkNotice: "ประตูลิฟต์เปิดออกสู่ชั้น 1 โถงทางเข้าหลัก",
      audioText: "เข้าลิฟต์แล้วกดปุ่มชั้น 1 เพื่อลงไปยังชั้นล่างค่ะ"
    },

    // --- ชั้น 2: ลิฟต์ -> จุดคัดกรอง/วัดความดัน ชั้น 2 ---
    {
      from: "elevator_2",
      to: "vital_signs_2",
      distance: 15,
      instruction: "ออกจากลิฟต์แล้วเดินตรงไป 15 เมตร จะพบเคาน์เตอร์พยาบาลวัดความดันหน้าห้องตรวจ",
      arrow: "straight",
      landmarkNotice: "เคาน์เตอร์พยาบาลและเครื่องวัดความดันกลางชั้น 2",
      audioText: "ออกจากลิฟต์แล้วเดินตรงไป 15 เมตร จะพบจุดวัดความดันชั้น 2 ค่ะ"
    },
    {
      from: "vital_signs_2",
      to: "elevator_2",
      distance: 15,
      instruction: "เดินตรงไปทางด้านหลังจะพบโถงลิฟต์โดยสาร",
      arrow: "straight",
      landmarkNotice: "โถงลิฟต์โดยสาร ชั้น 2",
      audioText: "เดินตรงกลับไปที่ลิฟต์โดยสารค่ะ"
    },

    // --- ชั้น 2: จุดวัดความดัน -> คลินิกอายุรกรรม ---
    {
      from: "vital_signs_2",
      to: "clinic_med",
      distance: 25,
      instruction: "จากจุดวัดความดัน เลี้ยวซ้ายเดินตามทางเดินสีเขียวไปยังคลินิกอายุรกรรม (ห้อง 201-208)",
      arrow: "turn-left",
      landmarkNotice: "ป้าย 'คลินิกอายุรกรรม' และที่นั่งรอตรวจสีเขียว",
      audioText: "เลี้ยวซ้ายแล้วเดินตรงไป 25 เมตร จะถึงคลินิกอายุรกรรม ห้องตรวจ 201 ถึง 208 ค่ะ นำเอกสารไปวางที่ตะกร้าหน้าห้องตรวจได้เลยค่ะ"
    },
    {
      from: "clinic_med",
      to: "vital_signs_2",
      distance: 25,
      instruction: "เดินออกจากคลินิกอายุรกรรม เลี้ยวขวาเพื่อกลับมาที่เคาน์เตอร์กลาง",
      arrow: "turn-right",
      landmarkNotice: "เคาน์เตอร์พยาบาลกลางชั้น 2",
      audioText: "เดินตรงออกมาแล้วเลี้ยวขวาเพื่อกลับมาเคาน์เตอร์กลางค่ะ"
    },

    // --- ชั้น 2: จุดวัดความดัน -> ศัลยกรรม/กระดูก ---
    {
      from: "vital_signs_2",
      to: "clinic_surgery",
      distance: 25,
      instruction: "จากจุดวัดความดัน เลี้ยวขวาเดินตรงไปตามทางเดินปีกขวาไปยังคลินิกศัลยกรรม (ห้อง 209-215)",
      arrow: "turn-right",
      landmarkNotice: "ป้าย 'คลินิกศัลยกรรมและกระดูก' ที่นั่งรอตรวจสีส้ม",
      audioText: "เลี้ยวขวาแล้วเดินตรงไป 25 เมตร จะถึงคลินิกศัลยกรรมและกระดูกค่ะ"
    },
    {
      from: "clinic_surgery",
      to: "vital_signs_2",
      distance: 25,
      instruction: "เดินออกจากคลินิกศัลยกรรม เลี้ยวซ้ายเพื่อกลับมาที่เคาน์เตอร์กลาง",
      arrow: "turn-left",
      landmarkNotice: "เคาน์เตอร์พยาบาลกลางชั้น 2",
      audioText: "เดินกลับมาทางซ้ายสู่เคาน์เตอร์พยาบาลกลางชั้น 2 ค่ะ"
    },

    // --- ชั้น 2: จุดวัดความดัน -> ห้องเอกซเรย์ (X-Ray) ---
    {
      from: "vital_signs_2",
      to: "xray",
      distance: 35,
      instruction: "เดินเฉียงไปทางขวาบนตามป้าย 'แผนกรังสีวินิจฉัย / เอกซเรย์'",
      arrow: "slight-right",
      landmarkNotice: "ประตูห้องเอกซเรย์ขนาดใหญ่ มีป้ายไฟเตือนรังสี",
      audioText: "เดินเฉียงไปทางขวาบน 35 เมตร จะถึงแผนกเอกซเรย์ ยื่นใบนัดที่ช่องกระจกได้เลยค่ะ"
    },
    {
      from: "xray",
      to: "vital_signs_2",
      distance: 35,
      instruction: "ออกจากห้องเอกซเรย์ เดินตรงกลับมาที่เคาน์เตอร์พยาบาลกลาง",
      arrow: "straight",
      landmarkNotice: "เคาน์เตอร์พยาบาลกลางชั้น 2",
      audioText: "เดินตรงกลับมายังเคาน์เตอร์พยาบาลกลางชั้น 2 ค่ะ"
    },

    // --- ชั้น 2: จุดวัดความดัน -> ห้องน้ำ ชั้น 2 ---
    {
      from: "vital_signs_2",
      to: "wc_floor2",
      distance: 30,
      instruction: "เลี้ยวซ้ายเดินเลยคลินิกอายุรกรรมไป จะพบทางเข้าห้องน้ำชั้น 2",
      arrow: "turn-left",
      landmarkNotice: "ป้ายห้องน้ำสีน้ำเงิน",
      audioText: "เลี้ยวซ้ายเดินตรงไปตามทางเดิน 30 เมตร ห้องน้ำจะอยู่สุดทางเดินด้านซ้ายค่ะ"
    },
    {
      from: "wc_floor2",
      to: "vital_signs_2",
      distance: 30,
      instruction: "ออกจากห้องน้ำ เดินตรงกลับมายังเคาน์เตอร์พยาบาลกลาง",
      arrow: "straight",
      landmarkNotice: "เคาน์เตอร์พยาบาลกลางชั้น 2",
      audioText: "เดินตรงกลับมาที่เคาน์เตอร์พยาบาลกลางค่ะ"
    }
  ],

  // ฐานข้อมูลจำลองผู้ป่วย (Mock Patients) สำหรับระบบล็อกอินผ่านมือถือ
  mockPatients: [
    {
      hn: "67-001234",
      citizenId: "1609900123456",
      phone: "0812345678",
      name: "นายสมชาย ใจดี",
      age: 68,
      rights: "บัตรทอง (สปสช.)",
      appointment: {
        date: "วันนี้",
        time: "09:30 น.",
        department: "คลินิกอายุรกรรม (ห้องตรวจ 203)",
        doctor: "นพ.ประสิทธิ์ แพทย์ชำนาญการ",
        currentStepNotice: "⚠️ กรุณาไปเจาะเลือดที่ห้องแล็บ (ชั้น 1) ก่อนเข้าพบแพทย์",
        targetNode: "lab_blood",
        finalNode: "clinic_med"
      }
    },
    {
      hn: "67-005678",
      citizenId: "1609900567890",
      phone: "0898765432",
      name: "นางสมศรี รักษาดี",
      age: 62,
      rights: "สิทธิข้าราชการ/เบิกตรง",
      appointment: {
        date: "วันนี้",
        time: "10:15 น.",
        department: "แผนกรังสีวินิจฉัย / เอกซเรย์ (X-Ray)",
        doctor: "พญ.วิภาวรรณ รังสีแพทย์",
        currentStepNotice: "กรุณายื่นใบนัดที่ช่องเบอร์ 1 แผนกเอกซเรย์ (ชั้น 2)",
        targetNode: "xray",
        finalNode: "xray"
      }
    },
    {
      hn: "67-009999",
      citizenId: "1609900999999",
      phone: "0861112222",
      name: "ด.ช. กิตติพงษ์ เก่งมาก",
      age: 9,
      rights: "บัตรประกันสุขภาพ",
      appointment: {
        date: "วันนี้",
        time: "11:00 น.",
        department: "ห้องจ่ายยา & จุดชำระเงิน",
        doctor: "พบแพทย์เสร็จสิ้นแล้ว",
        currentStepNotice: "💊 รอเรียกคิวรับยาและชำระเงินที่ช่อง 1-8 (ชั้น 1)",
        targetNode: "pharmacy",
        finalNode: "pharmacy"
      }
    }
  ],

  // บัญชีเจ้าหน้าที่สำหรับฝ่าย IT / บุคลากร รพ.
  staffAccounts: [
    { username: "admin", password: "1234", name: "ผู้ดูแลระบบ IT รพ.สวรรค์ประชารักษ์", role: "IT Admin" },
    { username: "staff", password: "1234", name: "เจ้าหน้าที่ประชาสัมพันธ์ รพ.", role: "Staff" }
  ]
};

// ส่งออกให้ใช้งานในเบราว์เซอร์
window.HOSPITAL_DATA = HOSPITAL_DATA;
