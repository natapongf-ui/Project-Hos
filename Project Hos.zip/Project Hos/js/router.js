/**
 * Router Engine: จัดการคำนวณเส้นทางเดินในอาคารด้วย Dijkstra's Algorithm
 */

class HospitalRouter {
  constructor(hospitalData) {
    this.data = hospitalData;
    this.graph = {};
    this.buildGraph();
  }

  // สร้าง Adjacency List จาก Edges
  buildGraph() {
    this.graph = {};

    // เพิ่ม Node ทั้งหมดลงใน graph
    Object.keys(this.data.nodes).forEach(nodeId => {
      this.graph[nodeId] = [];
    });

    // เพิ่ม Edge เชื่อมต่อ
    this.data.edges.forEach(edge => {
      if (this.graph[edge.from]) {
        this.graph[edge.from].push({
          to: edge.to,
          distance: edge.distance,
          instruction: edge.instruction,
          arrow: edge.arrow,
          landmarkNotice: edge.landmarkNotice,
          audioText: edge.audioText
        });
      }
    });
  }

  /**
   * ค้นหาเส้นทางที่สั้นที่สุดจาก startId ไปยัง endId ด้วย Dijkstra
   */
  findPath(startId, endId) {
    if (!this.data.nodes[startId] || !this.data.nodes[endId]) {
      return null;
    }

    if (startId === endId) {
      return {
        totalDistance: 0,
        estimatedTimeMinutes: 1,
        pathNodes: [this.data.nodes[startId]],
        steps: [{
          stepNumber: 1,
          fromNode: this.data.nodes[startId],
          toNode: this.data.nodes[endId],
          instruction: "คุณอยู่ที่นี่แล้ว",
          arrow: "arrived",
          distance: 0,
          landmarkNotice: this.data.nodes[endId].landmark,
          audioText: "คุณอยู่ที่ " + this.data.nodes[endId].name + " แล้วค่ะ",
          photo: this.data.nodes[endId].photo,
          isDestination: true
        }]
      };
    }

    const distances = {};
    const previous = {};
    const previousEdge = {};
    const unvisited = new Set();

    Object.keys(this.data.nodes).forEach(nodeId => {
      distances[nodeId] = Infinity;
      previous[nodeId] = null;
      previousEdge[nodeId] = null;
      unvisited.add(nodeId);
    });

    distances[startId] = 0;

    while (unvisited.size > 0) {
      // หาโหนดที่ระยะทางน้อยที่สุดในกลุ่มที่ยังไม่เคยสำรวจ
      let closestNode = null;
      let minDistance = Infinity;

      unvisited.forEach(nodeId => {
        if (distances[nodeId] < minDistance) {
          minDistance = distances[nodeId];
          closestNode = nodeId;
        }
      });

      if (closestNode === null || distances[closestNode] === Infinity) {
        break; // ไม่มีเส้นทางเชื่อมต่อ
      }

      if (closestNode === endId) {
        break; // ถึงปลายทางแล้ว
      }

      unvisited.delete(closestNode);

      // สำรวจเพื่อนบ้าน
      const neighbors = this.graph[closestNode] || [];
      for (const neighbor of neighbors) {
        if (!unvisited.has(neighbor.to)) continue;

        const alt = distances[closestNode] + neighbor.distance;
        if (alt < distances[neighbor.to]) {
          distances[neighbor.to] = alt;
          previous[neighbor.to] = closestNode;
          previousEdge[neighbor.to] = neighbor;
        }
      }
    }

    // หากไม่พบเส้นทางไปถึงปลายทาง
    if (distances[endId] === Infinity) {
      return null;
    }

    // สร้างลำดับขั้นตอนย้อนกลับจาก endId สู่ startId
    const pathNodeIds = [];
    const stepEdges = [];
    let curr = endId;

    while (curr) {
      pathNodeIds.unshift(curr);
      if (previousEdge[curr]) {
        stepEdges.unshift(previousEdge[curr]);
      }
      curr = previous[curr];
    }

    // แปลงเป็น Steps ที่เป็นมิตรกับผู้ป่วย
    const steps = [];
    let cumulativeDistance = 0;

    for (let i = 0; i < stepEdges.length; i++) {
      const edge = stepEdges[i];
      const fromNode = this.data.nodes[pathNodeIds[i]];
      const toNode = this.data.nodes[pathNodeIds[i + 1]];
      cumulativeDistance += edge.distance;

      steps.push({
        stepNumber: i + 1,
        fromNode: fromNode,
        toNode: toNode,
        instruction: edge.instruction,
        arrow: edge.arrow,
        distance: edge.distance,
        landmarkNotice: edge.landmarkNotice || toNode.landmark,
        audioText: edge.audioText || edge.instruction,
        photo: toNode.photo, // รูปมุมมองของโหนดต่อไป
        isDestination: (i === stepEdges.length - 1)
      });
    }

    // เพิ่มขั้นตอนสุดท้ายเมื่อถึงห้องเป้าหมาย
    const destinationNode = this.data.nodes[endId];
    steps.push({
      stepNumber: steps.length + 1,
      fromNode: destinationNode,
      toNode: destinationNode,
      instruction: `ถึงจุดหมาย: ${destinationNode.name} เรียบร้อยแล้ว`,
      arrow: "arrived",
      distance: 0,
      landmarkNotice: `สังเกต: ${destinationNode.landmark}`,
      audioText: `ถึงแล้วค่ะ คุณอยู่ที่ ${destinationNode.name} เรียบร้อยแล้ว สังเกตป้ายหน้าห้องตามรูปได้เลยค่ะ`,
      photo: destinationNode.photo,
      isDestination: true
    });

    const totalDistance = distances[endId];
    // ความเร็วเดินเฉลี่ยผู้สูงอายุประมาณ 35 เมตรต่อนาที + เวลาเผื่อขึ้นลิฟต์/มองป้าย 1 นาที
    const estimatedMinutes = Math.max(1, Math.ceil(totalDistance / 35) + (steps.some(s => s.arrow.includes('elevator')) ? 2 : 0));

    return {
      totalDistance: totalDistance,
      estimatedTimeMinutes: estimatedMinutes,
      pathNodes: pathNodeIds.map(id => this.data.nodes[id]),
      steps: steps
    };
  }
}

window.HospitalRouter = HospitalRouter;

